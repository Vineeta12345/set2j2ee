/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Vineeta
 */
@WebServlet(urlPatterns = {"/Servlet"})
public class Servlet extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) 
    { 
        try { 
  
            response.setContentType("text/html"); 
            /* 
             * The response's character encoding is only set from the given 
             * content type if this method is called before getWriter is called. 
             * This method may be called repeatedly to change content type and 
             * character encoding. 
             */
            PrintWriter out = response.getWriter(); 
            /* 
             * The Java PrintWriter class ( java.io.PrintWriter ) enables you to 
             * write formatted data to an underlying Writer . For instance, 
             * writing int, long and other primitive data formatted as text, 
             * rather than as their byte values 
             */
            // getting value from the query string 
            String n = request.getParameter("uname"); 
            out.print("Hello " + n); 
            /* out.println is used to print on the client web browser */
            out.close(); 
        } 
        catch (Exception e) { 
            System.out.println(e); 
        } 
    } 

}
